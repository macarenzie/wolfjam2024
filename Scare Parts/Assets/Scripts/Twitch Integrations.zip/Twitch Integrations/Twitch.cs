using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Events;
using System.Net.Sockets;
using System.IO;
using System.Globalization;
/// <summary>
/// Name: Twitch Connect
/// Purpose: Connect to specfied streamer's twitch chat and read chatlogs to parge commands
/// Author(s): Katie Hellmann, PabloMakes Twitch Integration Tutorial
/// </summary>
public class TwitchConnect : MonoBehaviour
{
    public UnityEvent<string, string> OnChatMessage;
    TcpClient TwitchTV;
    StreamReader Reader;
    StreamWriter Writer;

    private float pingCounter = 0;
    const string URL = "irc.chat.twitch.tv";
    const int PORT = 6667;

    private string user;
    private string oauth;
    private string channel;

    private void Awake()
    {
        user = TwitchAuth.ChannelName;
        oauth = TwitchAuth.OAuthToken;
        channel = TwitchAuth.ChannelName;

        ConnectToTwitch();
    }

    private void ConnectToTwitch()
    {
        TwitchTV = new TcpClient(URL, PORT);
        Reader = new StreamReader(TwitchTV.GetStream());
        Writer = new StreamWriter(TwitchTV.GetStream());

        Writer.WriteLine("PASS " + oauth);
        Writer.WriteLine("NICK " + user.ToLower());
        Writer.WriteLine("JOIN #" + channel.ToLower());
        Writer.Flush();
    }

    void Update()
    {
        pingCounter += Time.deltaTime;
        if (pingCounter > 60)
        {
            Writer.WriteLine("PING " + URL);
            Writer.Flush();
            pingCounter = 0;
        }

        if (!TwitchTV.Connected)
        {
            ConnectToTwitch();
        }

        if (TwitchTV.Available > 0)
        {
            string message = Reader.ReadLine();
            if (message.Contains("PRIVMSG"))
            {
                int splitPoint = message.IndexOf("!");
                string chatter = message.Substring(1, splitPoint - 1);
                splitPoint = message.IndexOf(":", 1);
                string msg = message.Substring(splitPoint + 1);

                OnChatMessage?.Invoke(chatter, msg);
            }

            Debug.Log(message);
        }
    }
}