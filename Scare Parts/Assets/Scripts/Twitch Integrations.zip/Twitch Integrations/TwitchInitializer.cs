using TwitchSDK;
using TwitchSDK.Interop;
using UnityEngine;
public class TwitchInitializer : MonoBehaviour
{
    GameTask<AuthenticationInfo> AuthInfoTask;
    GameTask<AuthState> curAuthState;

    void Start()
    {
        UpdateAuthState();
    }

    public void UpdateAuthState()
    {
        curAuthState = Twitch.API.GetAuthState();
        if (curAuthState.MaybeResult.Status == AuthStatus.LoggedIn)
        {
            // user is logged in
        }
        if (curAuthState.MaybeResult.Status == AuthStatus.LoggedOut)
        {
            GetAuthInformation();
        }
        if (curAuthState.MaybeResult.Status == AuthStatus.WaitingForCode)
        {
            // Waiting for code
            TwitchOAuthScope tscopes = new TwitchOAuthScope("chat:read chat:edit");
            var UserAuthInfo = Twitch.API.GetAuthenticationInfo(tscopes).MaybeResult;
            if (UserAuthInfo == null)
            {
                // User is still loading
            }
            // We have reached the state where we can ask the user to login
            Application.OpenURL("{UserAuthInfo.Uri}{UserAuthInfo.UserCode}");
        }
    }

    // Triggered by something external, like a login button on a options menu screen
    public void GetAuthInformation()
    {
        // Check to see if the user is currently logged in or not.
        if (AuthInfoTask == null)
        {
            // This example uses all scopes, we suggest you only request the scopes you actively need.
            var scopes = TwitchOAuthScope.Bits.Read.Scope + " " + TwitchOAuthScope.Channel.ManageBroadcast.Scope + " " + TwitchOAuthScope.Channel.ManagePolls.Scope + " " + TwitchOAuthScope.Channel.ManagePredictions.Scope + " " + TwitchOAuthScope.Channel.ManageRedemptions.Scope + " " + TwitchOAuthScope.Channel.ReadHypeTrain.Scope + " " + TwitchOAuthScope.Clips.Edit.Scope + " " + TwitchOAuthScope.User.ReadSubscriptions.Scope;
            TwitchOAuthScope tscopes = new TwitchOAuthScope(scopes);
            AuthInfoTask = Twitch.API.GetAuthenticationInfo(tscopes);
        }
    }
}
