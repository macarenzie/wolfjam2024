/// <summary>
/// Name: Twitch Auth
/// Purpose: Secure credential holding for duration of session
/// Author(s): Katie Hellmann Gator Flack
/// </summary>
using UnityEngine;

public class TwitchAuth : MonoBehaviour
{
    //public static string TwitchName => System.Environment.GetEnvironmentVariable("TWITCH_USERNAME");
    //public static string OAuthToken => System.Environment.GetEnvironmentVariable("TWITCH_OAUTH_TOKEN");
    // public static string ChannelName => System.Environment.GetEnvironmentVariable("TWITCH_CHANNEL_NAME");
    public static string TwitchName = "83i0g3ewr4aqbtxwgrmvniz6jdadne";
    public static string OAuthToken = "oauth:zjyzg1f6uh6o28q43usj2aclr03zge";
    public static string ChannelName = "MF_Gat0r";
}

//these enviorment variables need to be set up in unity